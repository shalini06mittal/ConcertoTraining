package com.techgatha.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootReactiveSimpleApplicationTests {

	@Test
	void contextLoads() {
	}

}
