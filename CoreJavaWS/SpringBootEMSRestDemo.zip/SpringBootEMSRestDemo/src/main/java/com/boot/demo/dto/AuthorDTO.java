package com.boot.demo.dto;

public class AuthorDTO {

	
	
}
