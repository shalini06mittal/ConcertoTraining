package com.boot.demo.dto;

public enum Messages {
	SUCCESS, FAILURE
}
