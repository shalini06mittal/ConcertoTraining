package com.eduramp.ms.ForexService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForexServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
