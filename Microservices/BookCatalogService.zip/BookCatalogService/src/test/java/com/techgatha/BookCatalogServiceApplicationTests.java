package com.techgatha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
